import pandas as pd
import geopandas as gpd
import folium

# --- Chargement des données projet ---
df = pd.read_csv(
    "C:\\Users\\achve\\OneDrive - ESIEE Paris\\Documents\\projet_data\\data\\cleaned\\data_patologies_cleaned.csv",
    low_memory=False
)

# --- Agréger les données par région ---
df_region = df.groupby("region", as_index=False).agg({
    "prev": "mean",   # Moyenne de la prévalence
    "Npop": "sum",    # Somme de la population
    "tri": "mean"     # Moyenne du tri
})

# --- Charger le GeoJSON des communes (avec code_insee_region et code_departement) ---
geo_communes = gpd.read_file(
    "C:\\Users\\achve\\OneDrive - ESIEE Paris\\Documents\\projet_data\\data\\raw\\datagouv-communes.geojson"
)

# --- Agréger le GeoJSON par région ---
geo_regions = geo_communes.dissolve(by="code_insee_region", as_index=False)

# Ajouter le nom des régions pour fusionner
region_names = df[["region", "code_insee_region"]].drop_duplicates()
geo_regions = geo_regions.merge(region_names, on="code_insee_region", how="left")

# --- Fusion des données projet avec les contours géographiques ---
geo_merged = geo_regions.merge(df_region, on="region", how="left")

# --- Création de la carte ---
map_regions = folium.Map(location=[46.6, 2.4], zoom_start=6, tiles="CartoDB positron")

# --- Choropleth par prévalence ---
folium.Choropleth(
    geo_data=geo_merged,
    name="Prévalence par région",
    data=geo_merged,
    columns=["region", "prev"],
    key_on="feature.properties.region",
    fill_color="YlOrRd",
    fill_opacity=0.8,
    line_opacity=0.2,
    nan_fill_color="lightgrey",
    legend_name="Prévalence moyenne par région"
).add_to(map_regions)

# --- Ajouter popup avec informations ---
for _, r in geo_merged.iterrows():
    folium.Marker(
        location=[r["geometry"].centroid.y, r["geometry"].centroid.x],
        popup=f"{r['region']}<br>Prévalence : {r['prev']:.2f}<br>Population : {int(r['Npop'])}<br>Tri moyen : {r['tri']:.2f}"
    ).add_to(map_regions)

# --- Sauvegarde de la carte ---
map_regions.save(
    "C:\\Users\\achve\\OneDrive - ESIEE Paris\\Documents\\projet_data\\data\\outputs\\carte_prev_regions.html"
)
print(" Carte enregistrée : carte_prev_regions.html")
