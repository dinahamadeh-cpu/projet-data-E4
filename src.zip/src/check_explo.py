import pandas as pd
import os

# Chemins
exploration_file = "C:\\Users\\achve\\OneDrive - ESIEE Paris\\Documents\\projet_data\\data\\outputs\\exploration_summary.txt"
df_file = "C:\\Users\\achve\\OneDrive - ESIEE Paris\\Documents\\projet_data\\data\\cleaned\\data_patologies_cleaned.csv"

# 1️⃣ Vérifier que le fichier de synthèse existe
if os.path.exists(exploration_file):
    print(f"✅ Le fichier de synthèse '{exploration_file}' existe.")
    with open(exploration_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
        print(f"📄 Aperçu (5 premières lignes) :\n{''.join(lines[:5])}")
else:
    print(f"❌ Le fichier de synthèse '{exploration_file}' est manquant !")

# 2️⃣ Vérifier que le DataFrame nettoyé existe
if os.path.exists(df_file):
    df = pd.read_csv(df_file)
    print(f"\n✅ DataFrame chargé : {df.shape[0]} lignes, {df.shape[1]} colonnes")
else:
    print(f"\n❌ DataFrame nettoyé '{df_file}' introuvable !")

# 3️⃣ Vérifier que les colonnes clés sont intactes
colonnes_a_verifier = [
    "tri", "Niveau prioritaire", 
    "patho_niv1", "patho_niv2", "patho_niv3", 
    "Ntop", "Npop", "prev"
]

colonnes_manquantes = [col for col in colonnes_a_verifier if col not in df.columns]
if colonnes_manquantes:
    print(f"❌ Colonnes manquantes : {colonnes_manquantes}")
else:
    print("✅ Toutes les colonnes clés sont présentes.")

# 4️⃣ Vérifier si les valeurs de tri et niveau_prioritaire sont raisonnables
print("\n🔹 Valeurs uniques de 'tri' (5 premières) :", df['tri'].unique()[:5])
print("🔹 Valeurs uniques de 'Niveau prioritaire' :", df['Niveau prioritaire'].unique())
