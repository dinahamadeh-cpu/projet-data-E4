import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os


df_file = "C:/Users/achve/OneDrive - ESIEE Paris/Documents/projet_data/data/cleaned/data_patologies_cleaned.csv"
output_summary = "C:/Users/achve/OneDrive - ESIEE Paris/Documents/projet_data/data/outputs/exploration_summary_enriched.txt"

# Charger le dataset
df = pd.read_csv(df_file)
print(f" Données chargées : {df.shape[0]} lignes, {df.shape[1]} colonnes")

# Statistiques descriptives de tri
tri_stats = df['tri'].describe()
tri_quantiles = df['tri'].quantile([0.25, 0.5, 0.75])
print("\nStatistiques descriptives de 'tri' :")
print(tri_stats)

# Niveau prioritaire : extraire les valeurs numériques
df['niveau_prioritaire_clean'] = df['Niveau prioritaire'].astype(str).str.extract(r'(\d+)').astype(float)

# Distribution et statistiques tri par niveau prioritaire
tri_by_niveau = df.groupby('niveau_prioritaire_clean')['tri'].describe()
print("\nStatistiques de tri par niveau prioritaire :")
print(tri_by_niveau)

# Tri moyen par pathologie top 10
for niv in ['patho_niv1', 'patho_niv2', 'patho_niv3']:
    tri_patho = df.groupby(niv)['tri'].mean().sort_values(ascending=False)
    print(f"\nTri moyen par {niv} (top 10) :")
    print(tri_patho.head(10))

# Tri par sexe et âge
tri_by_sexe = df.groupby('libelle_sexe')['tri'].describe()
tri_by_age = df.groupby('libelle_classe_age')['tri'].describe()
print("\nTri par sexe :")
print(tri_by_sexe)
print("\nTri par classe d'âge :")
print(tri_by_age)

# Relation Ntop / Npop / prev
corr_matrix = df[['Ntop','Npop','prev','tri']].corr()
print("\nMatrice de corrélation :")
print(corr_matrix)

# Pathologies les plus fréquentes par sexe / âge / région
freq_patho_sexe = df.groupby(['patho_niv1','libelle_sexe'])['Ntop'].sum().unstack(fill_value=0)
freq_patho_age = df.groupby(['patho_niv1','libelle_classe_age'])['Ntop'].sum().unstack(fill_value=0)
freq_patho_region = df.groupby(['patho_niv1','region'])['Ntop'].sum().unstack(fill_value=0)

print("\nPathologies les plus fréquentes par sexe (top 5 patho par sexe) :")
print(freq_patho_sexe.sum(axis=1).sort_values(ascending=False).head(5))
print("\nPathologies les plus fréquentes par âge (top 5 patho) :")
print(freq_patho_age.sum(axis=1).sort_values(ascending=False).head(5))
print("\nPathologies les plus fréquentes par région (top 5 patho) :")
print(freq_patho_region.sum(axis=1).sort_values(ascending=False).head(5))

# Export synthèse
with open(output_summary, "w", encoding="utf-8") as f:
    f.write(" Synthèse exploration complète du dataset\n\n")
    f.write("Statistiques de 'tri' :\n")
    f.write(tri_stats.to_string() + "\n\n")
    f.write("Tri par niveau prioritaire :\n")
    f.write(tri_by_niveau.to_string() + "\n\n")
    f.write("Matrice de corrélation (Ntop/Npop/prev/tri) :\n")
    f.write(corr_matrix.to_string() + "\n\n")
    f.write("Pathologies les plus fréquentes par sexe (top 5) :\n")
    f.write(freq_patho_sexe.sum(axis=1).sort_values(ascending=False).head(5).to_string() + "\n")
    f.write("Pathologies les plus fréquentes par âge (top 5) :\n")
    f.write(freq_patho_age.sum(axis=1).sort_values(ascending=False).head(5).to_string() + "\n")
    f.write("Pathologies les plus fréquentes par région (top 5) :\n")
    f.write(freq_patho_region.sum(axis=1).sort_values(ascending=False).head(5).to_string() + "\n")

print(f"\n Synthèse enregistrée dans : {output_summary}")
